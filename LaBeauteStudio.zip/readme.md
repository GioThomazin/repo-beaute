# Lounge - Free Responsive HTML Restaurant Website Template

#### Preview

 - [Demo](https://themewagon.github.io/Lounge/)

#### Download
 - [Download from ThemeWagon]( https://themewagon.com/themes/lounge)
 
 
## Getting Started

1. Clone from Github 
```
git clone https://github.com/themewagon/Lounge.git
```

## Author

Design and code is completely written by StyleShout design and development team.  


## License

 - Design and Code is Copyright &copy; [StyleShout](https://styleshout.com/)
 - Licensed cover under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)

